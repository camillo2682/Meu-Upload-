import { pgTable, serial, text, bigint, timestamp } from "drizzle-orm/pg-core";

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  originalName: text("original_name").notNull(),
  storedName: text("stored_name").notNull(),
  mimeType: text("mime_type").notNull(),
  sizeBytes: bigint("size_bytes", { mode: "number" }).notNull(),
  username: text("username").notNull(),
  unlockCode: text("unlock_code").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
