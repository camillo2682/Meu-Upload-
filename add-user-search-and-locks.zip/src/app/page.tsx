import { db } from "@/db";
import { files } from "@/db/schema";
import { desc } from "drizzle-orm";
import FileManager, { type FileItem } from "@/components/FileManager";
import { CloudUpload, ShieldCheck, Smartphone, Zap, Lock, Search } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const rows = await db.select().from(files).orderBy(desc(files.createdAt));

  const initialFiles: FileItem[] = rows.map((row) => ({
    id: row.id,
    originalName: row.originalName,
    storedName: row.storedName,
    mimeType: row.mimeType,
    sizeBytes: row.sizeBytes,
    username: row.username,
    createdAt: row.createdAt.toISOString(),
  }));

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top,_#eef2ff,_#f8fafc_55%)]">
      <div className="mx-auto flex min-h-screen max-w-5xl flex-col px-4 py-10 sm:px-6 lg:px-8">
        <header className="flex flex-col items-center gap-3 text-center">
          <div className="flex items-center gap-2.5 rounded-full bg-white px-4 py-2 shadow-sm ring-1 ring-slate-200">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-white">
              <CloudUpload size={18} />
            </div>
            <span className="text-sm font-semibold tracking-tight text-slate-800">Meu Upload</span>
          </div>
          <h1 className="max-w-2xl text-[clamp(1.9rem,4.5vw,2.75rem)] font-bold leading-tight text-slate-950">
            Guarde seus arquivos e baixe de qualquer lugar
          </h1>
          <p className="max-w-xl text-sm text-slate-600 sm:text-base">
            Envie um arquivo do computador ou do celular e acesse para download a qualquer momento,
            em qualquer dispositivo. Cada arquivo é protegido com um código de desbloqueio.
          </p>

          <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Feature icon={<Zap size={16} />} label="Upload rápido com progresso em tempo real" />
            <Feature icon={<Smartphone size={16} />} label="Funciona no PC, tablet e celular" />
            <Feature icon={<Lock size={16} />} label="Arquivos protegidos por código de desbloqueio" />
          </div>

          <div className="mt-2 flex items-center gap-2 rounded-full bg-indigo-50 px-4 py-1.5 ring-1 ring-indigo-200">
            <Search size={14} className="text-indigo-600" />
            <span className="text-xs font-medium text-indigo-700">Busque arquivos por usuário</span>
          </div>
        </header>

        <div className="mt-10 flex-1">
          <FileManager initialFiles={initialFiles} />
        </div>

        <footer className="mt-16 pb-4 text-center text-xs text-slate-400">
          Meu Upload · seus arquivos, sempre protegidos.
        </footer>
      </div>
    </main>
  );
}

function Feature({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-2 rounded-xl bg-white/70 px-3 py-2 text-xs font-medium text-slate-600 shadow-sm ring-1 ring-slate-200/70">
      <span className="text-indigo-600">{icon}</span>
      {label}
    </div>
  );
}
