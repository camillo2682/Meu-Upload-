import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { files } from "@/db/schema";
import { ilike } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const username = request.nextUrl.searchParams.get("username");

  if (!username || username.trim().length === 0) {
    return NextResponse.json({ error: "Informe um nome de usuário." }, { status: 400 });
  }

  const rows = await db
    .select()
    .from(files)
    .where(ilike(files.username, `%${username.trim()}%`))
    .orderBy(files.createdAt);

  return NextResponse.json(
    rows.map((row) => ({
      id: row.id,
      originalName: row.originalName,
      storedName: row.storedName,
      mimeType: row.mimeType,
      sizeBytes: row.sizeBytes,
      username: row.username,
      createdAt: row.createdAt.toISOString(),
    }))
  );
}
