import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { files } from "@/db/schema";
import { eq } from "drizzle-orm";
import { readFile, stat } from "fs/promises";
import { join } from "path";

export const dynamic = "force-dynamic";

const UPLOAD_DIR = join(process.cwd(), "uploads");

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const fileId = Number(id);
    if (isNaN(fileId)) {
      return NextResponse.json({ error: "ID inválido." }, { status: 400 });
    }

    const code = request.nextUrl.searchParams.get("code");
    if (!code) {
      return NextResponse.json({ error: "Código de desbloqueio necessário." }, { status: 401 });
    }

    const [row] = await db.select().from(files).where(eq(files.id, fileId)).limit(1);
    if (!row) {
      return NextResponse.json({ error: "Arquivo não encontrado." }, { status: 404 });
    }

    if (row.unlockCode !== code.trim()) {
      return NextResponse.json({ error: "Código de desbloqueio incorreto." }, { status: 403 });
    }

    const filePath = join(UPLOAD_DIR, row.storedName);
    const fileBuffer = await readFile(filePath);

    return new NextResponse(fileBuffer, {
      headers: {
        "Content-Type": row.mimeType,
        "Content-Disposition": `attachment; filename="${row.originalName}"`,
        "Content-Length": String(fileBuffer.length),
      },
    });
  } catch (err) {
    console.error("Download error:", err);
    return NextResponse.json({ error: "Erro ao baixar arquivo." }, { status: 500 });
  }
}
