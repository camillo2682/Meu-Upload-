import { NextResponse } from "next/server";
import { db } from "@/db";
import { files } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(files).orderBy(desc(files.createdAt));

  return NextResponse.json(
    rows.map((row) => ({
      id: row.id,
      originalName: row.originalName,
      storedName: row.storedName,
      mimeType: row.mimeType,
      sizeBytes: row.sizeBytes,
      username: row.username,
      createdAt: row.createdAt.toISOString(),
    }))
  );
}
