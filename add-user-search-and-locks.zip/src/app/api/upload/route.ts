import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { files } from "@/db/schema";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { randomUUID } from "crypto";

export const dynamic = "force-dynamic";

const UPLOAD_DIR = join(process.cwd(), "uploads");

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File | null;
    const username = formData.get("username") as string | null;
    const unlockCode = formData.get("unlockCode") as string | null;

    if (!file) {
      return NextResponse.json({ error: "Nenhum arquivo enviado." }, { status: 400 });
    }
    if (!username || username.trim().length === 0) {
      return NextResponse.json({ error: "Nome de usuário é obrigatório." }, { status: 400 });
    }
    if (!unlockCode || unlockCode.trim().length === 0) {
      return NextResponse.json({ error: "Código de desbloqueio é obrigatório." }, { status: 400 });
    }

    // Ensure upload directory exists
    await mkdir(UPLOAD_DIR, { recursive: true });

    const ext = file.name.includes(".") ? `.${file.name.split(".").pop()}` : "";
    const storedName = `${randomUUID()}${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(join(UPLOAD_DIR, storedName), buffer);

    const [inserted] = await db
      .insert(files)
      .values({
        originalName: file.name,
        storedName,
        mimeType: file.type || "application/octet-stream",
        sizeBytes: file.size,
        username: username.trim(),
        unlockCode: unlockCode.trim(),
      })
      .returning();

    return NextResponse.json({
      id: inserted.id,
      originalName: inserted.originalName,
      storedName: inserted.storedName,
      mimeType: inserted.mimeType,
      sizeBytes: inserted.sizeBytes,
      username: inserted.username,
      createdAt: inserted.createdAt.toISOString(),
    });
  } catch (err) {
    console.error("Upload error:", err);
    return NextResponse.json({ error: "Erro ao fazer upload." }, { status: 500 });
  }
}
