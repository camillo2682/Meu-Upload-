import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { files } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const { fileId, code } = await request.json();

    if (!fileId || !code) {
      return NextResponse.json({ error: "ID e código são obrigatórios." }, { status: 400 });
    }

    const [row] = await db.select().from(files).where(eq(files.id, fileId)).limit(1);
    if (!row) {
      return NextResponse.json({ error: "Arquivo não encontrado." }, { status: 404 });
    }

    if (row.unlockCode !== String(code).trim()) {
      return NextResponse.json({ success: false, error: "Código incorreto." }, { status: 403 });
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Unlock error:", err);
    return NextResponse.json({ error: "Erro ao verificar código." }, { status: 500 });
  }
}
