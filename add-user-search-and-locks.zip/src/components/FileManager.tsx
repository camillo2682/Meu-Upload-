"use client";

import { useState, useRef, useCallback } from "react";
import {
  CloudUpload,
  Lock,
  Unlock,
  Search,
  Download,
  Trash2,
  X,
  FileText,
  FileImage,
  FileVideo,
  FileAudio,
  File,
  User,
  KeyRound,
  Loader2,
} from "lucide-react";

export type FileItem = {
  id: number;
  originalName: string;
  storedName: string;
  mimeType: string;
  sizeBytes: number;
  username: string;
  createdAt: string;
};

type Tab = "upload" | "files" | "search";

function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function getFileIcon(mimeType: string) {
  if (mimeType.startsWith("image/")) return <FileImage size={20} />;
  if (mimeType.startsWith("video/")) return <FileVideo size={20} />;
  if (mimeType.startsWith("audio/")) return <FileAudio size={20} />;
  if (mimeType.startsWith("text/") || mimeType.includes("pdf") || mimeType.includes("document"))
    return <FileText size={20} />;
  return <File size={20} />;
}

export default function FileManager({ initialFiles }: { initialFiles: FileItem[] }) {
  const [activeTab, setActiveTab] = useState<Tab>("upload");
  const [files, setFiles] = useState<FileItem[]>(initialFiles);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<FileItem[] | null>(null);
  const [searchLoading, setSearchLoading] = useState(false);

  // Upload state
  const [uploadUsername, setUploadUsername] = useState("");
  const [uploadCode, setUploadCode] = useState("");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [uploadSuccess, setUploadSuccess] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Unlock modal state
  const [unlockModal, setUnlockModal] = useState<{ open: boolean; file: FileItem | null }>({
    open: false,
    file: null,
  });
  const [unlockCode, setUnlockCode] = useState("");
  const [unlockError, setUnlockError] = useState("");
  const [unlockLoading, setUnlockLoading] = useState(false);

  const refreshFiles = useCallback(async () => {
    try {
      const res = await fetch("/api/files");
      if (res.ok) {
        const data = await res.json();
        setFiles(data);
      }
    } catch {}
  }, []);

  const handleUpload = async () => {
    if (!uploadFile || !uploadUsername.trim() || !uploadCode.trim()) {
      setUploadError("Preencha todos os campos.");
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setUploadError("");
    setUploadSuccess("");

    const formData = new FormData();
    formData.append("file", uploadFile);
    formData.append("username", uploadUsername.trim());
    formData.append("unlockCode", uploadCode.trim());

    try {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/api/upload");

      const promise = new Promise<void>((resolve, reject) => {
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            setUploadProgress(Math.round((e.loaded / e.total) * 100));
          }
        };
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve();
          } else {
            try {
              const err = JSON.parse(xhr.responseText);
              reject(new Error(err.error || "Erro no upload"));
            } catch {
              reject(new Error("Erro no upload"));
            }
          }
        };
        xhr.onerror = () => reject(new Error("Erro de rede"));
      });

      xhr.send(formData);
      await promise;

      setUploadSuccess("Arquivo enviado com sucesso!");
      setUploadFile(null);
      setUploadCode("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      setUploadProgress(0);
      await refreshFiles();
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Erro no upload");
    } finally {
      setUploading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    setSearchLoading(true);
    setSearchResults(null);
    try {
      const res = await fetch(`/api/search?username=${encodeURIComponent(searchQuery.trim())}`);
      if (res.ok) {
        setSearchResults(await res.json());
      }
    } catch {
      setSearchResults([]);
    } finally {
      setSearchLoading(false);
    }
  };

  const handleUnlock = async () => {
    if (!unlockModal.file || !unlockCode.trim()) {
      setUnlockError("Digite o código de desbloqueio.");
      return;
    }

    setUnlockLoading(true);
    setUnlockError("");

    try {
      const res = await fetch("/api/unlock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fileId: unlockModal.file.id, code: unlockCode.trim() }),
      });

      if (res.ok) {
        // Trigger download
        const downloadUrl = `/api/download/${unlockModal.file.id}?code=${encodeURIComponent(unlockCode.trim())}`;
        window.open(downloadUrl, "_blank");
        setUnlockModal({ open: false, file: null });
        setUnlockCode("");
      } else {
        const data = await res.json();
        setUnlockError(data.error || "Código incorreto.");
      }
    } catch {
      setUnlockError("Erro ao verificar código.");
    } finally {
      setUnlockLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Tabs */}
      <div className="flex gap-1 rounded-xl bg-white p-1 shadow-sm ring-1 ring-slate-200">
        <TabButton
          active={activeTab === "upload"}
          onClick={() => setActiveTab("upload")}
          icon={<CloudUpload size={16} />}
          label="Upload"
        />
        <TabButton
          active={activeTab === "files"}
          onClick={() => setActiveTab("files")}
          icon={<Lock size={16} />}
          label="Arquivos"
        />
        <TabButton
          active={activeTab === "search"}
          onClick={() => setActiveTab("search")}
          icon={<Search size={16} />}
          label="Buscar"
        />
      </div>

      {/* Upload Tab */}
      {activeTab === "upload" && (
        <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-slate-800">
            <CloudUpload size={20} className="text-indigo-600" />
            Enviar arquivo
          </h2>

          <div className="grid gap-4 sm:grid-cols-2">
            {/* Username */}
            <div>
              <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-700">
                <User size={14} className="text-indigo-500" />
                Nome de usuário
              </label>
              <input
                type="text"
                value={uploadUsername}
                onChange={(e) => setUploadUsername(e.target.value)}
                placeholder="Ex: joao.silva"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            {/* Unlock Code */}
            <div>
              <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-700">
                <KeyRound size={14} className="text-indigo-500" />
                Código de desbloqueio
              </label>
              <input
                type="text"
                value={uploadCode}
                onChange={(e) => setUploadCode(e.target.value)}
                placeholder="Ex: 1234"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
              <p className="mt-1 text-xs text-slate-500">
                Quem quiser baixar precisará deste código.
              </p>
            </div>
          </div>

          {/* File Input */}
          <div className="mt-4">
            <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-700">
              <File size={14} className="text-indigo-500" />
              Arquivo
            </label>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 px-4 py-8 text-center transition-colors hover:border-indigo-400 hover:bg-indigo-50/50"
            >
              <CloudUpload size={28} className="text-slate-400" />
              {uploadFile ? (
                <p className="text-sm font-medium text-slate-700">{uploadFile.name}</p>
              ) : (
                <p className="text-sm text-slate-500">Clique para selecionar um arquivo</p>
              )}
            </div>
            <input
              ref={fileInputRef}
              type="file"
              onChange={(e) => setUploadFile(e.target.files?.[0] ?? null)}
              className="hidden"
            />
          </div>

          {/* Progress */}
          {uploading && (
            <div className="mt-4">
              <div className="mb-1 flex justify-between text-xs text-slate-600">
                <span>Enviando...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-slate-200">
                <div
                  className="h-full rounded-full bg-indigo-600 transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Error / Success */}
          {uploadError && (
            <p className="mt-3 text-sm font-medium text-red-600">{uploadError}</p>
          )}
          {uploadSuccess && (
            <p className="mt-3 text-sm font-medium text-emerald-600">{uploadSuccess}</p>
          )}

          {/* Submit */}
          <button
            onClick={handleUpload}
            disabled={uploading || !uploadFile || !uploadUsername.trim() || !uploadCode.trim()}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {uploading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                Enviando...
              </>
            ) : (
              <>
                <CloudUpload size={16} />
                Enviar arquivo
              </>
            )}
          </button>
        </div>
      )}

      {/* Files Tab */}
      {activeTab === "files" && (
        <div>
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-slate-800">
            <Lock size={20} className="text-indigo-600" />
            Arquivos enviados
          </h2>
          {files.length === 0 ? (
            <p className="rounded-xl bg-white px-4 py-8 text-center text-sm text-slate-500 shadow-sm ring-1 ring-slate-200">
              Nenhum arquivo enviado ainda.
            </p>
          ) : (
            <div className="grid gap-3">
              {files.map((f) => (
                <FileCard key={f.id} file={f} onUnlock={() => setUnlockModal({ open: true, file: f })} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Search Tab */}
      {activeTab === "search" && (
        <div>
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-slate-800">
            <Search size={20} className="text-indigo-600" />
            Buscar por usuário
          </h2>
          <div className="flex gap-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              placeholder="Digite o nome do usuário..."
              className="flex-1 rounded-xl border border-slate-300 px-4 py-2.5 text-sm text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
            <button
              onClick={handleSearch}
              disabled={searchLoading || !searchQuery.trim()}
              className="flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {searchLoading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <Search size={16} />
              )}
              Buscar
            </button>
          </div>

          {searchResults !== null && (
            <div className="mt-4">
              {searchResults.length === 0 ? (
                <p className="rounded-xl bg-white px-4 py-8 text-center text-sm text-slate-500 shadow-sm ring-1 ring-slate-200">
                  Nenhum arquivo encontrado para esse usuário.
                </p>
              ) : (
                <>
                  <p className="mb-3 text-sm text-slate-600">
                    {searchResults.length} arquivo(s) encontrado(s)
                  </p>
                  <div className="grid gap-3">
                    {searchResults.map((f) => (
                      <FileCard key={f.id} file={f} onUnlock={() => setUnlockModal({ open: true, file: f })} />
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Unlock Modal */}
      {unlockModal.open && unlockModal.file && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl ring-1 ring-slate-200">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-lg font-semibold text-slate-800">
                <Lock size={20} className="text-indigo-600" />
                Desbloquear arquivo
              </h3>
              <button
                onClick={() => {
                  setUnlockModal({ open: false, file: null });
                  setUnlockCode("");
                  setUnlockError("");
                }}
                className="rounded-lg p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </div>

            <p className="mb-1 text-sm font-medium text-slate-700">
              {unlockModal.file.originalName}
            </p>
            <p className="mb-4 text-xs text-slate-500">
              Enviado por <span className="font-semibold text-slate-700">{unlockModal.file.username}</span> • {formatDate(unlockModal.file.createdAt)}
            </p>

            <div className="mb-4 flex items-center gap-3 rounded-xl bg-amber-50 px-4 py-3 ring-1 ring-amber-200">
              <Lock size={18} className="text-amber-600" />
              <p className="text-sm text-amber-800">
                Este arquivo está protegido. Digite o código de desbloqueio para baixar.
              </p>
            </div>

            <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-slate-700">
              <KeyRound size={14} className="text-indigo-500" />
              Código de desbloqueio
            </label>
            <input
              type="text"
              value={unlockCode}
              onChange={(e) => setUnlockCode(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleUnlock()}
              placeholder="Digite o código..."
              autoFocus
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />

            {unlockError && (
              <p className="mt-2 text-sm font-medium text-red-600">{unlockError}</p>
            )}

            <div className="mt-4 flex gap-2">
              <button
                onClick={() => {
                  setUnlockModal({ open: false, file: null });
                  setUnlockCode("");
                  setUnlockError("");
                }}
                className="flex-1 rounded-xl bg-slate-100 px-4 py-2.5 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-200"
              >
                Cancelar
              </button>
              <button
                onClick={handleUnlock}
                disabled={unlockLoading || !unlockCode.trim()}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {unlockLoading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" />
                    Verificando...
                  </>
                ) : (
                  <>
                    <Unlock size={16} />
                    Desbloquear
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-sm font-semibold transition-colors ${
        active
          ? "bg-indigo-600 text-white shadow-sm"
          : "text-slate-600 hover:bg-slate-100 hover:text-slate-800"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function FileCard({ file, onUnlock }: { file: FileItem; onUnlock: () => void }) {
  return (
    <div className="group flex items-center gap-4 rounded-xl bg-white px-4 py-3 shadow-sm ring-1 ring-slate-200 transition-all hover:shadow-md hover:ring-slate-300">
      {/* File icon */}
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">
        {getFileIcon(file.mimeType)}
      </div>

      {/* Info */}
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-slate-800">{file.originalName}</p>
        <p className="flex items-center gap-2 text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <User size={12} />
            {file.username}
          </span>
          <span>•</span>
          <span>{formatBytes(file.sizeBytes)}</span>
          <span>•</span>
          <span>{formatDate(file.createdAt)}</span>
        </p>
      </div>

      {/* Lock badge + Download button */}
      <div className="flex items-center gap-2">
        <span className="flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold text-amber-700 ring-1 ring-amber-200">
          <Lock size={12} />
          Protegido
        </span>
        <button
          onClick={onUnlock}
          className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-indigo-700"
        >
          <Download size={14} />
          Baixar
        </button>
      </div>
    </div>
  );
}
